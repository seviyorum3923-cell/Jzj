package com.bilinmeyen.jarvis

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

class JarvisService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var porcupine: PorcupineManager? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var onSpoken: (() -> Unit)? = null
    private var userName = "Kayra"
    private var started = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_STICKY
        started = true

        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        userName = prefs.getString("name", "Kayra") ?: "Kayra"
        val key = prefs.getString("key", "") ?: ""

        goForeground("Jarvis dinliyor...")

        if (key.isBlank()) {
            fail("AccessKey girilmemis")
            return START_NOT_STICKY
        }

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("tr", "TR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onError(utteranceId: String?) {
                        main.post { val cb = onSpoken; onSpoken = null; cb?.invoke() }
                    }
                    override fun onDone(utteranceId: String?) {
                        main.post { val cb = onSpoken; onSpoken = null; cb?.invoke() }
                    }
                })
            }
        }

        try {
            porcupine = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(applicationContext, PorcupineManagerCallback { _ ->
                    main.post { onWake() }
                })
            porcupine?.start()
        } catch (e: Exception) {
            fail("Hata: " + e.message)
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun onWake() {
        try { porcupine?.stop() } catch (e: Exception) {}
        speak("Efendim $userName") { listen() }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("Ses tanima servisi yok") { resume() }
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                resume()
            }
            override fun onResults(results: Bundle?) {
                main.removeCallbacksAndMessages(null)
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull() ?: ""
                val reply = CommandHandler(applicationContext).handle(text)
                speak(reply) { resume() }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        r.startListening(i)
        main.postDelayed({ resume() }, 20000)
    }

    private fun speak(text: String, then: () -> Unit) {
        onSpoken = then
        val t = tts
        if (t == null) {
            onSpoken = null
            then()
        } else {
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
        }
    }

    private fun resume() {
        main.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        try { porcupine?.start() } catch (e: Exception) {}
    }

    private fun goForeground(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }

    private fun fail(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        stopSelf()
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        try { porcupine?.stop() } catch (e: Exception) {}
        try { porcupine?.delete() } catch (e: Exception) {}
        try { recognizer?.destroy() } catch (e: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
