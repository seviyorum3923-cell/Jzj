package com.bilinmeyen.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        fun label(t: String, size: Float = 15f): TextView {
            val v = TextView(this)
            v.text = t
            v.textSize = size
            v.setPadding(0, pad / 2, 0, 0)
            return v
        }

        fun btn(t: String, action: () -> Unit): Button {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { action() }
            return b
        }

        val keyBox = EditText(this)
        keyBox.hint = "Picovoice AccessKey"
        keyBox.setSingleLine()
        keyBox.setText(prefs.getString("key", ""))

        val nameBox = EditText(this)
        nameBox.hint = "Adin"
        nameBox.setSingleLine()
        nameBox.setText(prefs.getString("name", "Kayra"))

        root.addView(label("JARVIS", 28f))
        root.addView(label("1) Picovoice AccessKey (console.picovoice.ai, ucretsiz):"))
        root.addView(keyBox)
        root.addView(label("2) Jarvis sana ne desin:"))
        root.addView(nameBox)

        root.addView(btn("3) Izinleri ver") {
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        })

        root.addView(btn("4) Diger uygulamalarin ustunde goster izni") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })

        root.addView(btn("5) Pil kisitlamasini kaldir (Jarvis'i sec)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })

        root.addView(btn("BASLAT") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Once izinleri ver", Toast.LENGTH_LONG).show()
            } else {
                prefs.edit()
                    .putString("key", keyBox.text.toString().trim())
                    .putString("name", nameBox.text.toString().trim().ifEmpty { "Kayra" })
                    .apply()
                startForegroundService(Intent(this, JarvisService::class.java))
                Toast.makeText(this, "Jarvis basladi. Jarvis de!", Toast.LENGTH_LONG).show()
            }
        })

        root.addView(btn("DURDUR") {
            stopService(Intent(this, JarvisService::class.java))
        })

        root.addView(label("Komut ornekleri:\n- Instagram ac\n- WhatsApp ac\n- Ahmet'e mesaj at nasilsin\n- Ahmet'i ara\n- Fener ac / fener kapat\n- Sesi ac / sesi kis\n- Muzik ac\n- YouTube'da komik videolar ara\n- Saat kac"))

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }
}
