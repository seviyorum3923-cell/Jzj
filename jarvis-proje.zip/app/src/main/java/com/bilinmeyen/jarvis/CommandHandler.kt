package com.bilinmeyen.jarvis

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.ContactsContract
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class CommandHandler(private val ctx: Context) {

    private val searchRe = Regex(
        "^(youtube|google)['’]?(?:da|de|ta|te)?\\s+(.+?)\\s+ara(?:t)?$",
        RegexOption.IGNORE_CASE
    )
    private val callRe = Regex("^(\\S+)\\s+ara(?:r misin)?$", RegexOption.IGNORE_CASE)

    fun handle(raw: String): String {
        val text = raw.trim()
        if (text.isEmpty()) return "Seni duyamadim."
        val t = norm(text)
        return try {
            val sm = searchRe.matchEntire(text)
            val cm = callRe.matchEntire(text)
            when {
                t.contains("mesaj") -> sendMessage(text)
                t.contains("saat kac") ->
                    "Saat " + SimpleDateFormat("HH:mm", Locale("tr")).format(Date())
                t.contains("fener") -> torch(t)
                t.startsWith("ses") -> volume(t)
                t.contains("muzik") -> music()
                sm != null -> webSearch(sm.groupValues[1], sm.groupValues[2])
                cm != null -> call(cm.groupValues[1])
                t.endsWith(" ac") || t.endsWith(" baslat") || t.endsWith(" calistir") -> openApp(t)
                else -> "Anlayamadim: $text"
            }
        } catch (e: Exception) {
            "Bir hata oldu."
        }
    }

    private fun torch(t: String): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Fener bulamadim."
        val on = !(t.contains("kapat") || t.contains("sondur"))
        cm.setTorchMode(id, on)
        return if (on) "Fener acildi." else "Fener kapandi."
    }

    private fun volume(t: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val down = t.contains("kis") || t.contains("azalt") || t.contains("kapat") || t.contains("dusur")
        val dir = if (down) AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE
        repeat(3) { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI) }
        return if (down) "Ses kisildi." else "Ses acildi."
    }

    private fun music(): String {
        val pm = ctx.packageManager
        for (p in listOf("com.spotify.music", "com.google.android.apps.youtube.music")) {
            val i = pm.getLaunchIntentForPackage(p)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(i)
                return "Muzik aciliyor."
            }
        }
        return "Muzik uygulamasi bulamadim."
    }

    private fun webSearch(site: String, query: String): String {
        val q = Uri.encode(query)
        val url = if (site.equals("youtube", ignoreCase = true))
            "https://www.youtube.com/results?search_query=$q"
        else
            "https://www.google.com/search?q=$q"
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return "$query araniyor."
    }

    private fun call(who: String): String {
        val found = try {
            findContact(who)
        } catch (e: SecurityException) {
            return "Rehber izni yok."
        } ?: return "$who adinda kisiyi bulamadim."
        val num = found.second.filter { it.isDigit() || it == '+' }
        return try {
            ctx.startActivity(
                Intent(Intent.ACTION_CALL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "${found.first} araniyor."
        } catch (e: SecurityException) {
            ctx.startActivity(
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "${found.first} icin arama ekrani acildi."
        }
    }

    private fun openApp(t: String): String {
        var name = t.removeSuffix(" ac").removeSuffix(" baslat").removeSuffix(" calistir").trim()
        for (f in listOf(" uygulamasini", " uygulamasi", " uygulamayi", " uygulama")) {
            name = name.removeSuffix(f)
        }
        name = name.trim()
        if (name.length < 3) return "Hangi uygulamayi acayim?"

        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val match = list
            .map { it to norm(it.loadLabel(pm).toString()) }
            .filter { (_, ln) -> ln.length >= 3 && (name.startsWith(ln) || ln.startsWith(name)) }
            .minByOrNull { (_, ln) -> abs(ln.length - name.length) }
            ?: return "$name diye bir uygulama bulamadim."

        val pkg = match.first.activityInfo.packageName
        val launch = pm.getLaunchIntentForPackage(pkg) ?: return "Acamadim."
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(launch)
        return match.first.loadLabel(pm).toString() + " aciliyor."
    }

    private fun sendMessage(raw: String): String {
        val re = Regex(
            "^(?:whatsapp\\S*\\s+)?(\\S+)\\s+mesaj\\s+(?:at|gönder|gonder|yaz)\\s*(.*)$",
            RegexOption.IGNORE_CASE
        )
        val m = re.matchEntire(raw.trim())
            ?: return "Mesaj icin soyle de: Ahmet'e mesaj at, nasilsin."
        val who = m.groupValues[1]
        val body = m.groupValues[2].trim()
        if (body.isEmpty()) return "Mesaji da soyle."

        val found = try {
            findContact(who)
        } catch (e: SecurityException) {
            return "Rehber izni yok."
        } ?: return "$who adinda kisiyi rehberde bulamadim."

        val num = intlNumber(found.second)
        val uri = Uri.parse("https://wa.me/$num?text=" + Uri.encode(body))
        return try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, uri)
                    .setPackage("com.whatsapp")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "${found.first} icin WhatsApp mesaji hazir. Gonder tusuna bas."
        } catch (e: Exception) {
            val sms = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num"))
                .putExtra("sms_body", body)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(sms)
            "${found.first} icin SMS hazir. Gonder tusuna bas."
        }
    }

    private fun findContact(token: String): Pair<String, String>? {
        val clean = norm(token)
        val cands = mutableListOf(clean)
        if (clean.endsWith("ye") || clean.endsWith("ya") || clean.endsWith("yi") || clean.endsWith("yu"))
            cands.add(clean.dropLast(2))
        if (clean.isNotEmpty() && clean.last() in "eaiu") cands.add(clean.dropLast(1))

        val rows = mutableListOf<Pair<String, String>>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                rows.add((c.getString(0) ?: "") to (c.getString(1) ?: ""))
            }
        }
        for (cand in cands) {
            if (cand.length < 2) continue
            val hit = rows.firstOrNull { (n, _) ->
                val nn = norm(n)
                nn == cand || nn.split(" ").any { it == cand } || nn.startsWith(cand)
            }
            if (hit != null) return hit
        }
        return null
    }

    private fun intlNumber(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.drop(2)
        else if (d.startsWith("0")) d = "90" + d.drop(1)
        else if (d.length == 10 && d.startsWith("5")) d = "90$d"
        return d
    }

    private fun norm(s: String): String =
        s.lowercase(Locale("tr"))
            .replace('ç', 'c').replace('ş', 's').replace('ğ', 'g')
            .replace('ı', 'i').replace('ö', 'o').replace('ü', 'u')
            .replace("'", "").replace("’", "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
}
